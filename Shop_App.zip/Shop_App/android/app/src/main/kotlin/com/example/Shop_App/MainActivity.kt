package com.example.Shop_App

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
